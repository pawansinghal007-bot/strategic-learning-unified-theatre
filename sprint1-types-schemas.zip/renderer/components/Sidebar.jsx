import React, { useEffect, useState } from 'react'

// ─── Theme definitions ────────────────────────────────────────────────────────
const THEMES = {
  teal: {
    name: 'Forest teal',
    swatch: '#1D9E75',
    sidebar:       '#ffffff',
    border:        '#e5e7eb',
    brand:         '#111827',
    brandSub:      '#9ca3af',
    tile:          '#0F6E56',
    tileText:      '#9FE1CB',
    sectionLabel:  '#9ca3af',
    itemText:      '#6b7280',
    itemHover:     '#f0fdf4',
    itemHoverText: '#111827',
    activeBg:      '#E1F5EE',
    activeBorder:  '#1D9E75',
    activeText:    '#085041',
    badge:         '#E1F5EE',
    badgeText:     '#085041',
    footerDot:     '#1D9E75',
    footerText:    '#9ca3af',
  },
  midnight: {
    name: 'Midnight dark',
    swatch: '#378ADD',
    sidebar:       '#0f1117',
    border:        '#1e2028',
    brand:         '#f0f2f5',
    brandSub:      '#4a4f5c',
    tile:          '#185FA5',
    tileText:      '#B5D4F4',
    sectionLabel:  '#3a3d48',
    itemText:      '#6b7280',
    itemHover:     '#1a1d24',
    itemHoverText: '#e2e8f0',
    activeBg:      '#0C447C',
    activeBorder:  '#378ADD',
    activeText:    '#B5D4F4',
    badge:         '#0C447C',
    badgeText:     '#B5D4F4',
    footerDot:     '#378ADD',
    footerText:    '#3a3d48',
  },
  ember: {
    name: 'Ember amber',
    swatch: '#EF9F27',
    sidebar:       '#1a1410',
    border:        '#2e2418',
    brand:         '#faf0e0',
    brandSub:      '#6b5a40',
    tile:          '#854F0B',
    tileText:      '#FAC775',
    sectionLabel:  '#4a3820',
    itemText:      '#7a6040',
    itemHover:     '#241c14',
    itemHoverText: '#faf0e0',
    activeBg:      '#633806',
    activeBorder:  '#EF9F27',
    activeText:    '#FAC775',
    badge:         '#633806',
    badgeText:     '#FAC775',
    footerDot:     '#EF9F27',
    footerText:    '#4a3820',
  },
  slate: {
    name: 'Slate minimal',
    swatch: '#5F5E5A',
    sidebar:       '#ffffff',
    border:        '#e5e7eb',
    brand:         '#2C2C2A',
    brandSub:      '#B4B2A9',
    tile:          '#444441',
    tileText:      '#D3D1C7',
    sectionLabel:  '#B4B2A9',
    itemText:      '#888780',
    itemHover:     '#F1EFE8',
    itemHoverText: '#2C2C2A',
    activeBg:      '#F1EFE8',
    activeBorder:  '#5F5E5A',
    activeText:    '#2C2C2A',
    badge:         '#F1EFE8',
    badgeText:     '#5F5E5A',
    footerDot:     '#5F5E5A',
    footerText:    '#B4B2A9',
  },
  coral: {
    name: 'Coral warm',
    swatch: '#D85A30',
    sidebar:       '#fdf8f6',
    border:        '#f0ddd5',
    brand:         '#2d1208',
    brandSub:      '#c4a090',
    tile:          '#993C1D',
    tileText:      '#F5C4B3',
    sectionLabel:  '#c4a090',
    itemText:      '#a06040',
    itemHover:     '#FAECE7',
    itemHoverText: '#2d1208',
    activeBg:      '#FAECE7',
    activeBorder:  '#D85A30',
    activeText:    '#4A1B0C',
    badge:         '#FAECE7',
    badgeText:     '#993C1D',
    footerDot:     '#D85A30',
    footerText:    '#c4a090',
  },
}

// ─── Nav structure ────────────────────────────────────────────────────────────
const NAV_GROUPS = [
  {
    label: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard',     icon: 'ti-layout-dashboard' },
      { id: 'live',      label: 'Live Feed',      icon: 'ti-activity',        badge: true },
    ],
  },
  {
    label: 'Intelligence',
    items: [
      { id: 'llm',     label: 'Local LLM',         icon: 'ti-cpu' },
      { id: 'prompts', label: 'Prompt Templates',  icon: 'ti-file-text' },
      { id: 'robot',   label: 'Robot Framework',   icon: 'ti-robot' },
    ],
  },
  {
    label: 'Automation',
    items: [
      { id: 'browser', label: 'Browser Automation', icon: 'ti-world' },
      { id: 'git',     label: 'Git Monitor',         icon: 'ti-brand-git' },
    ],
  },
  {
    label: 'System',
    items: [
      { id: 'accounts',  label: 'Accounts',      icon: 'ti-users' },
      { id: 'progress',  label: 'Progress Log',  icon: 'ti-list' },
      { id: 'settings',  label: 'Settings',      icon: 'ti-settings' },
    ],
  },
]

// ─── Theme persistence key ────────────────────────────────────────────────────
const THEME_KEY = 'slut_sidebar_theme'

// ─── Component ────────────────────────────────────────────────────────────────
export default function Sidebar({ active, onSelect }) {
  const [version, setVersion]         = useState('')
  const [themeId, setThemeId]         = useState(() => localStorage.getItem(THEME_KEY) || 'teal')
  const [pickerOpen, setPickerOpen]   = useState(false)

  const t = THEMES[themeId] || THEMES.teal

  useEffect(() => {
    window.rotator.app.version().then((v) => setVersion(v)).catch(() => {})
  }, [])

  const pickTheme = (id) => {
    setThemeId(id)
    localStorage.setItem(THEME_KEY, id)
    setPickerOpen(false)
  }

  // ── Inline style helpers (avoids Tailwind purge issues with dynamic values) ──
  const s = {
    root: {
      width: '208px',
      minWidth: '208px',
      background: t.sidebar,
      borderRight: `1px solid ${t.border}`,
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      fontFamily: 'inherit',
      transition: 'background 0.25s, border-color 0.25s',
    },
    brandWrap: {
      padding: '14px 14px 12px',
      borderBottom: `1px solid ${t.border}`,
      flexShrink: 0,
    },
    brandRow: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '2px' },
    tile: {
      width: '26px', height: '26px',
      borderRadius: '6px',
      background: t.tile,
      color: t.tileText,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: '13px', flexShrink: 0,
    },
    brandName: { fontSize: '12px', fontWeight: 500, color: t.brand, lineHeight: 1.3 },
    brandSub:  { fontSize: '10px', color: t.brandSub, paddingLeft: '34px' },
    nav:       { flex: 1, padding: '8px 0', overflowY: 'auto' },
    sectionLabel: {
      fontSize: '10px', fontWeight: 500,
      color: t.sectionLabel,
      padding: '8px 14px 3px',
      letterSpacing: '0.06em',
    },
    footer: {
      padding: '10px 14px',
      borderTop: `1px solid ${t.border}`,
      display: 'flex', alignItems: 'center', gap: '8px',
      flexShrink: 0,
      position: 'relative',
    },
    footerDot: {
      width: '6px', height: '6px',
      borderRadius: '50%',
      background: t.footerDot,
      flexShrink: 0,
    },
    footerText: { fontSize: '11px', color: t.footerText, flex: 1 },
    paletteBtn: {
      width: '18px', height: '18px',
      borderRadius: '50%',
      background: t.swatch || t.activeBorder,
      border: `2px solid ${t.border}`,
      cursor: 'pointer',
      flexShrink: 0,
      outline: 'none',
    },
    pickerPanel: {
      position: 'absolute',
      bottom: '40px',
      left: '10px',
      background: t.sidebar,
      border: `1px solid ${t.border}`,
      borderRadius: '10px',
      padding: '10px',
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      zIndex: 50,
      boxShadow: '0 4px 16px rgba(0,0,0,0.12)',
      minWidth: '160px',
    },
    pickerItem: (id) => ({
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '6px 8px',
      borderRadius: '6px',
      cursor: 'pointer',
      background: themeId === id ? t.activeBg : 'transparent',
      border: 'none',
      width: '100%',
      textAlign: 'left',
    }),
    pickerSwatch: (th) => ({
      width: '14px', height: '14px',
      borderRadius: '50%',
      background: th.swatch,
      flexShrink: 0,
    }),
    pickerLabel: (id) => ({
      fontSize: '12px',
      color: themeId === id ? t.activeText : t.itemText,
      fontWeight: themeId === id ? 500 : 400,
    }),
  }

  return (
    <div style={s.root}>

      {/* Brand */}
      <div style={s.brandWrap}>
        <div style={s.brandRow}>
          <div style={s.tile}>
            <i className="ti ti-brain" aria-hidden="true" />
          </div>
          <span style={s.brandName}>SLUT</span>
        </div>
        <div style={s.brandSub}>Strategic Learning Theatre</div>
      </div>

      {/* Nav */}
      <nav style={s.nav} aria-label="Main navigation">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <div style={s.sectionLabel}>{group.label}</div>
            {group.items.map((item) => {
              const isActive = active === item.id
              return (
                <NavItem
                  key={item.id}
                  item={item}
                  isActive={isActive}
                  t={t}
                  onSelect={onSelect}
                />
              )
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div style={s.footer}>
        <div style={s.footerDot} />
        <span style={s.footerText}>daemon · v{version}</span>

        {/* Theme picker trigger */}
        <button
          style={s.paletteBtn}
          onClick={() => setPickerOpen((o) => !o)}
          title="Switch theme"
          aria-label="Switch sidebar theme"
        />

        {/* Theme picker panel */}
        {pickerOpen && (
          <div style={s.pickerPanel}>
            {Object.entries(THEMES).map(([id, th]) => (
              <button key={id} style={s.pickerItem(id)} onClick={() => pickTheme(id)}>
                <div style={s.pickerSwatch(th)} />
                <span style={s.pickerLabel(id)}>{th.name}</span>
                {themeId === id && (
                  <i className="ti ti-check" aria-hidden="true"
                    style={{ marginLeft: 'auto', fontSize: '12px', color: t.activeText }} />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── NavItem ──────────────────────────────────────────────────────────────────
function NavItem({ item, isActive, t, onSelect }) {
  const [hovered, setHovered] = useState(false)

  const style = {
    display: 'flex',
    alignItems: 'center',
    gap: '9px',
    padding: '7px 14px',
    fontSize: '12.5px',
    cursor: 'pointer',
    borderLeft: `2px solid ${isActive ? t.activeBorder : 'transparent'}`,
    background: isActive ? t.activeBg : hovered ? t.itemHover : 'transparent',
    color: isActive ? t.activeText : hovered ? t.itemHoverText : t.itemText,
    width: '100%',
    textAlign: 'left',
    border: 'none',
    borderLeft: `2px solid ${isActive ? t.activeBorder : 'transparent'}`,
    transition: 'background 0.12s, color 0.12s',
    outline: 'none',
  }

  const badgeStyle = {
    marginLeft: 'auto',
    fontSize: '10px',
    background: t.badge,
    color: t.badgeText,
    borderRadius: '10px',
    padding: '1px 6px',
    fontWeight: 500,
  }

  return (
    <button
      style={style}
      onClick={() => onSelect(item.id)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      aria-current={isActive ? 'page' : undefined}
    >
      <i className={`ti ${item.icon}`} aria-hidden="true" style={{ fontSize: '15px', flexShrink: 0 }} />
      <span>{item.label}</span>
      {item.badge && <span style={badgeStyle}>3</span>}
    </button>
  )
}
