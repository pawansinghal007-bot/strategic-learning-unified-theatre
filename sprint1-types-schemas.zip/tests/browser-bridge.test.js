import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { Command } from "commander";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import * as browserBridge from "../src/browser-bridge.js";

import {
  loadPromptLibrary,
  savePromptLibrary,
  addPrompt,
  findPrompt,
  updatePrompt,
  deletePrompt,
  listResponses,
  clearResponses,
  ensureBrowserDirs,
  BROWSER_RESPONSES_DIR,
  getBrowserResponsePlatform,
  ingestBrowserResponseFile,
  tagResponse,
  captureThread,
  sendPrompt,
  comparePrompts,
  sendPrompt,
  comparePrompts
} from "../src/browser-bridge.js";

vi.mock("playwright", () => {
  const fakeMessage = {
    evaluate: vi.fn(async () => "Mock browser response")
  };

  const fakePage = {
    goto: vi.fn(async () => {}),
    waitForLoadState: vi.fn(async () => {}),
    $(selector) {
      return Promise.resolve({});
    },
    fill: vi.fn(async () => {}),
    click: vi.fn(async () => {}),
    waitForSelector: vi.fn(async () => {}),
    $$: vi.fn(async () => [fakeMessage]),
    waitForTimeout: vi.fn(async () => {})
  };

  const fakeContext = {
    newPage: vi.fn(async () => fakePage),
    close: vi.fn(async () => {})
  };

  const fakeBrowser = {
    newContext: vi.fn(async () => fakeContext),
    close: vi.fn(async () => {})
  };

  return {
    chromium: { launch: vi.fn(async () => fakeBrowser) },
    firefox: { launch: vi.fn(async () => fakeBrowser) }
  };
});
import { ExperienceDb } from "../src/llm/experience-db.js";
import { MistakeTracker } from "../src/llm/mistake-tracker.js";
import { StorageMonitor } from "../src/storage-monitor.js";
import { DocumentIngester } from "../src/llm/document-ingester.js";

describe("Browser Bridge", () => {
  let tempDir;
  let originalHome;

  beforeEach(async () => {
    // Create temporary directory for testing
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "browser-bridge-test-"));
    
    // Save original HOME and override for tests
    originalHome = process.env.HOME;
    process.env.HOME = tempDir;
  });

  afterEach(async () => {
    // Restore original HOME
    if (originalHome) {
      process.env.HOME = originalHome;
    }
    
    try {
      await fs.rm(tempDir, { recursive: true, force: true });
    } catch {}
  });

  describe("Directory management", () => {
    it("creates browser directories", async () => {
      await ensureBrowserDirs();
      
      const profilesDir = path.join(tempDir, ".vscode-rotator", "browser-profiles");
      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      
      const profilesExists = await fs.stat(profilesDir).catch(() => false);
      const responsesExists = await fs.stat(responsesDir).catch(() => false);
      
      expect(profilesExists).toBeTruthy();
      expect(responsesExists).toBeTruthy();
    });
  });

  describe("Prompt Library", () => {
    it("loads empty library when no file exists", async () => {
      const library = await loadPromptLibrary();
      expect(library).toEqual([]);
    });

    it("adds a prompt to the library", async () => {
      const prompt = await addPrompt({
        name: "Test Prompt",
        template: "What is {{topic}}?",
        tags: ["test"],
        platforms: ["chatgpt"]
      });

      expect(prompt.id).toBeDefined();
      expect(prompt.name).toBe("Test Prompt");
      expect(prompt.template).toBe("What is {{topic}}?");
      expect(prompt.tags).toEqual(["test"]);
      expect(prompt.platforms).toEqual(["chatgpt"]);
    });

    it("finds a prompt by id", async () => {
      const added = await addPrompt({
        name: "Findable",
        template: "Test",
        tags: [],
        platforms: []
      });

      const found = await findPrompt(added.id);
      expect(found.id).toBe(added.id);
      expect(found.name).toBe("Findable");
    });

    it("updates a prompt", async () => {
      const prompt = await addPrompt({
        name: "Original",
        template: "Original template",
        tags: [],
        platforms: []
      });

      const updated = await updatePrompt(prompt.id, {
        name: "Updated",
        tags: ["new-tag"]
      });

      expect(updated.name).toBe("Updated");
      expect(updated.tags).toEqual(["new-tag"]);
      expect(updated.template).toBe("Original template"); // Unchanged
    });

    it("deletes a prompt", async () => {
      const prompt = await addPrompt({
        name: "To Delete",
        template: "Deletable",
        tags: [],
        platforms: []
      });

      const deleted = await deletePrompt(prompt.id);
      expect(deleted.id).toBe(prompt.id);

      await expect(findPrompt(prompt.id)).rejects.toThrow();
    });

    it("lists multiple prompts", async () => {
      await addPrompt({
        name: "Prompt 1",
        template: "Template 1",
        tags: ["tag1"],
        platforms: []
      });

      await addPrompt({
        name: "Prompt 2",
        template: "Template 2",
        tags: ["tag2"],
        platforms: ["claude"]
      });

      const library = await loadPromptLibrary();
      expect(library).toHaveLength(2);
      expect(library[0].name).toBe("Prompt 1");
      expect(library[1].name).toBe("Prompt 2");
    });

    it("throws when finding non-existent prompt", async () => {
      await expect(findPrompt("nonexistent-id")).rejects.toThrow(/not found/i);
    });

    it("throws when deleting non-existent prompt", async () => {
      await expect(deletePrompt("nonexistent-id")).rejects.toThrow(/not found/i);
    });
  });

  describe("Prompt persistence", () => {
    it("persists prompts across saves and loads", async () => {
      const prompt1 = await addPrompt({
        name: "Persistent 1",
        template: "Template 1",
        tags: ["persist"],
        platforms: ["chatgpt", "claude"]
      });

      const library = await loadPromptLibrary();
      expect(library).toHaveLength(1);
      expect(library[0].id).toBe(prompt1.id);
    });

    it("preserves prompt metadata on updates", async () => {
      const created = await addPrompt({
        name: "Test",
        template: "Original",
        tags: ["tag1"],
        platforms: ["chatgpt"]
      });

      const updated = await updatePrompt(created.id, {
        template: "Modified"
      });

      expect(updated.name).toBe("Test");
      expect(updated.tags).toEqual(["tag1"]);
      expect(updated.platforms).toEqual(["chatgpt"]);
      expect(updated.template).toBe("Modified");
    });
  });

  describe("Response management", () => {
    it("lists responses when none exist", async () => {
      await ensureBrowserDirs();
      const responses = await listResponses();
      expect(responses).toEqual([]);
    });

    it("creates response files", async () => {
      await ensureBrowserDirs();

      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      const testFile = path.join(responsesDir, "2026-05-19T10-30-45-chatgpt.md");
      const content = `# Response\n\nTest response`;
      
      await fs.writeFile(testFile, content, "utf8");

      const responses = await listResponses();
      expect(responses.length).toBeGreaterThan(0);
      expect(responses[0].filename).toContain("chatgpt");
    });

    it("writes browser responses atomically with tmp → fsync → rename → chmod", async () => {
      await ensureBrowserDirs();
      const writeFileSpy = vi.spyOn(fs, "writeFile");
      const openSpy = vi.spyOn(fs, "open");
      const renameSpy = vi.spyOn(fs, "rename");
      const chmodSpy = vi.spyOn(fs, "chmod");

      const fakeMessage = {
        evaluate: vi.fn(async () => "Mock browser response")
      };

      const fakePage = {
        goto: vi.fn(async () => {}),
        waitForLoadState: vi.fn(async () => {}),
        $(selector) {
          return Promise.resolve({});
        },
        fill: vi.fn(async () => {}),
        click: vi.fn(async () => {}),
        waitForSelector: vi.fn(async () => {}),
        $$: vi.fn(async () => [fakeMessage]),
        waitForTimeout: vi.fn(async () => {})
      };

      const fakeContext = {
        newPage: vi.fn(async () => fakePage),
        close: vi.fn(async () => {})
      };

      const launchSpy = vi.spyOn(browserBridge, "launchBrowser").mockResolvedValue(fakeContext);

      const response = await sendPrompt({
        platform: "chatgpt",
        prompt: "Test prompt",
        browserType: "chromium",
        headless: true,
        dryRun: false
      });

      const tmpCall = writeFileSpy.mock.calls.find(([filePath]) => filePath.endsWith(".tmp"));
      expect(tmpCall).toBeDefined();
      const tmpPath = tmpCall[0];
      expect(openSpy).toHaveBeenCalledWith(tmpPath, "r+");
      expect(renameSpy).toHaveBeenCalledWith(tmpPath, response.responsePath);
      expect(chmodSpy).toHaveBeenCalledWith(response.responsePath, 0o600);

      await expect(fs.stat(tmpPath)).rejects.toThrow();
      expect(await fs.stat(response.responsePath)).toBeTruthy();

      launchSpy.mockRestore();
      writeFileSpy.mockRestore();
      openSpy.mockRestore();
      renameSpy.mockRestore();
      chmodSpy.mockRestore();
    });

    it("clears old responses", async () => {
      await ensureBrowserDirs();
      
      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      
      // Create old file
      const oldFile = path.join(responsesDir, "2026-01-01T00-00-00-chatgpt.md");
      await fs.writeFile(oldFile, "Old response", "utf8");
      
      // Create new file
      const newFile = path.join(responsesDir, "2026-05-19T23-59-59-claude.md");
      await fs.writeFile(newFile, "New response", "utf8");

      // Would need actual date comparison logic in real implementation
      const result = await clearResponses({ platform: null });
      expect(result.deleted).toBeGreaterThanOrEqual(0);
    });

    it("filters responses by platform", async () => {
      await ensureBrowserDirs();
      
      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      
      await fs.writeFile(
        path.join(responsesDir, "2026-05-19T10-00-00-chatgpt.md"),
        "ChatGPT response",
        "utf8"
      );
      
      await fs.writeFile(
        path.join(responsesDir, "2026-05-19T10-01-00-claude.md"),
        "Claude response",
        "utf8"
      );

      const chatgptOnly = await listResponses({ platform: "chatgpt" });
      expect(chatgptOnly.length).toBeGreaterThan(0);
    });

    it("does not ingest compare report files", async () => {
      await ensureBrowserDirs();

      const sendPromptSpy = vi.spyOn(browserBridge, "sendPrompt").mockResolvedValue({
        platform: "chatgpt",
        prompt: "Test prompt",
        response: "Mock response",
        responsePath: path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-00-00-chatgpt.md"),
        timestamp: "2026-05-19T10:00:00"
      });
      const ingestSpy = vi.spyOn(browserBridge, "ingestBrowserResponseFile").mockResolvedValue(null);

      const result = await comparePrompts({
        prompt: "Compare this prompt",
        platforms: ["chatgpt"],
        browserType: "chromium",
        headless: true,
        dryRun: false
      });

      expect(result.reportPath).toContain("-compare.md");
      expect(ingestSpy.mock.calls.every(([filePath]) => !filePath.endsWith("-compare.md"))).toBe(true);

      sendPromptSpy.mockRestore();
      ingestSpy.mockRestore();
    });

    it("respects limit parameter", async () => {
      await ensureBrowserDirs();
      
      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      
      // Create multiple files
      for (let i = 0; i < 15; i++) {
        const time = String(i).padStart(2, "0");
        await fs.writeFile(
          path.join(responsesDir, `2026-05-19T10-${time}-00-chatgpt.md`),
          `Response ${i}`,
          "utf8"
        );
      }

      const limited = await listResponses({ limit: 5 });
      expect(limited.length).toBeLessThanOrEqual(5);
    });
  });

  describe("Response ingestion hook", () => {
    let appendChangesSpy;
    let ingestFromSnapshotSpy;
    let infoSpy;

    beforeEach(() => {
      appendChangesSpy = vi.spyOn(StorageMonitor.prototype, "appendChanges").mockResolvedValue({ appended: 1 });
      ingestFromSnapshotSpy = vi.spyOn(DocumentIngester.prototype, "ingestFromSnapshot").mockResolvedValue({ actions: [{ chunks: 2 }], ingested: 1, deleted: 0 });
      infoSpy = vi.spyOn(console, "info").mockImplementation(() => {});
    });

    afterEach(() => {
      appendChangesSpy.mockRestore();
      ingestFromSnapshotSpy.mockRestore();
      infoSpy.mockRestore();
    });

    it("triggers ingestion when browserResponsesIngest is true", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "Test response", "utf8");

      await ingestBrowserResponseFile(responsePath);

      expect(appendChangesSpy).toHaveBeenCalledWith([
        { event: "add", path: responsePath, label: "BrowserResponse" }
      ]);
      expect(ingestFromSnapshotSpy).toHaveBeenCalled();
      expect(infoSpy).toHaveBeenCalledWith("[browser-bridge] ingested 2026-05-19T10-30-45-chatgpt.md → 2 chunks");
    });

    it("skips ingestion when browserResponsesIngest is false", async () => {
      const configPath = path.join(tempDir, ".vscode-rotator", "config.json");
      await fs.mkdir(path.dirname(configPath), { recursive: true });
      await fs.writeFile(configPath, JSON.stringify({ browserResponsesIngest: false }, null, 2), "utf8");

      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "Test response", "utf8");

      await ingestBrowserResponseFile(responsePath);

      expect(appendChangesSpy).not.toHaveBeenCalled();
      expect(ingestFromSnapshotSpy).not.toHaveBeenCalled();
    });

    it("extracts platform correctly from response filenames", () => {
      expect(getBrowserResponsePlatform("2026-05-19T10-30-45-chatgpt.md")).toBe("chatgpt");
      expect(getBrowserResponsePlatform("2026-05-19T10-30-45-claude.md")).toBe("claude");
      expect(getBrowserResponsePlatform("2026-05-19T10-30-45-gemini.md")).toBe("gemini");
      expect(getBrowserResponsePlatform("2026-05-19T10-30-45-perplexity.md")).toBe("perplexity");
    });

    it("does not throw when ingestion fails", async () => {
      ingestFromSnapshotSpy.mockRejectedValueOnce(new Error("ingest failure"));
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "Test response", "utf8");

      await expect(ingestBrowserResponseFile(responsePath)).resolves.toBeNull();
      expect(infoSpy).not.toHaveBeenCalled();
      expect(appendChangesSpy).toHaveBeenCalled();
    });
  });

  describe("Response quality tagging", () => {
    it("tags a response as good", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "# Response\n\nGood response", "utf8");

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      await db.replaceDocumentsForFile(responsePath, [
        {
          content: "Good response",
          embedding: Array.from({ length: 768 }, () => 0),
          source_type: "llm-response",
          platform: "chatgpt",
          file_ts: "2026-05-19T10:30:45.000Z"
        }
      ]);
      await db.close();

      const result = await tagResponse("2026-05-19T10-30-45-chatgpt.md", {
        quality: "good",
        notes: "Accurate answer"
      });

      expect(result).toMatchObject({
        filename: "2026-05-19T10-30-45-chatgpt.md",
        quality: "good",
        notes: "Accurate answer",
        mistakeCreated: false
      });

      await db.open();
      const rows = await db.getDocumentsByFile(responsePath);
      await db.close();
      expect(rows[0].quality).toBe("good");
      expect(rows[0].notes).toBe("Accurate answer");
    });

    it("tags a response as bad and creates a mistake record", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "# Response\n\nBad response", "utf8");

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      await db.replaceDocumentsForFile(responsePath, [
        {
          content: "Bad response",
          embedding: Array.from({ length: 768 }, () => 0),
          source_type: "llm-response",
          platform: "chatgpt",
          file_ts: "2026-05-19T10:30:45.000Z"
        }
      ]);
      await db.close();

      const result = await tagResponse("2026-05-19T10-30-45-chatgpt.md", {
        quality: "bad",
        notes: "Wrong API used"
      });

      expect(result).toMatchObject({
        filename: "2026-05-19T10-30-45-chatgpt.md",
        quality: "bad",
        notes: "Wrong API used",
        mistakeCreated: true
      });

      const tracker = new MistakeTracker({ baseDir: tempDir });
      const mistakes = await tracker.listRubric();
      // MistakeTracker.listRubric returns rules not mistakes, so we verify via ExperienceDb directly
      const db2 = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db2.open();
      const mistakeEntries = db2.state.mistakes.filter((m) => m.description === "Wrong API used");
      await db2.close();
      expect(mistakeEntries.length).toBeGreaterThan(0);
    });

    it("tags a response as bad without notes and creates a default mistake record", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "# Response\n\nBad response", "utf8");

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      await db.replaceDocumentsForFile(responsePath, [
        {
          content: "Bad response",
          embedding: Array.from({ length: 768 }, () => 0),
          source_type: "llm-response",
          platform: "chatgpt",
          file_ts: "2026-05-19T10:30:45.000Z"
        }
      ]);
      await db.close();

      const trackerSpy = vi.spyOn(MistakeTracker.prototype, "addMistake");

      const result = await tagResponse("2026-05-19T10-30-45-chatgpt.md", {
        quality: "bad"
      });

      expect(result).toMatchObject({
        filename: "2026-05-19T10-30-45-chatgpt.md",
        quality: "bad",
        notes: null,
        mistakeCreated: true
      });
      expect(trackerSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          description: expect.stringContaining("2026-05-19T10-30-45-chatgpt.md"),
          category: "llm-response"
        })
      );

      trackerSpy.mockRestore();
    });

    it("tags a response as partial without notes — no mistake created", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "# Response\n\nPartial response", "utf8");

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      await db.replaceDocumentsForFile(responsePath, [
        {
          content: "Partial response",
          embedding: Array.from({ length: 768 }, () => 0),
          source_type: "llm-response",
          platform: "chatgpt",
          file_ts: "2026-05-19T10:30:45.000Z"
        }
      ]);
      await db.close();

      const result = await tagResponse("2026-05-19T10-30-45-chatgpt.md", {
        quality: "partial",
        notes: ""
      });

      expect(result).toMatchObject({
        filename: "2026-05-19T10-30-45-chatgpt.md",
        quality: "partial",
        notes: null,
        mistakeCreated: false
      });
    });

    it("throws when filename not found", async () => {
      await ensureBrowserDirs();
      await expect(
        tagResponse("no-such-file.md", { quality: "good", notes: "No file" })
      ).rejects.toThrow(/not found/i);
    });

    it("listResponses includes quality field after tagging", async () => {
      await ensureBrowserDirs();
      const responsePath = path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-19T10-30-45-chatgpt.md");
      await fs.writeFile(responsePath, "# Response\n\nTagged response", "utf8");

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      await db.replaceDocumentsForFile(responsePath, [
        {
          content: "Tagged response",
          embedding: Array.from({ length: 768 }, () => 0),
          source_type: "llm-response",
          platform: "chatgpt",
          file_ts: "2026-05-19T10:30:45.000Z"
        }
      ]);
      await db.close();

      await tagResponse("2026-05-19T10-30-45-chatgpt.md", {
        quality: "good",
        notes: "Looks fine"
      });

      const list = await listResponses({ platform: "chatgpt", limit: 10 });
      expect(list[0].quality).toBe("good");
      expect(list[0].notes).toBe("Looks fine");
    });
  });

  describe("Prompt templating", () => {
    it("validates prompt structure", async () => {
      const prompt = await addPrompt({
        name: "Template Test",
        template: "Explain {{topic}} in {{style}}",
        tags: ["template"],
        platforms: ["chatgpt"]
      });

      expect(prompt.template).toContain("{{topic}}");
      expect(prompt.template).toContain("{{style}}");
    });

    it("preserves template variables", async () => {
      const prompt = await addPrompt({
        name: "Complex",
        template: `
          Topic: {{topic}}
          Style: {{style}}
          Length: {{length}}
        `,
        tags: [],
        platforms: []
      });

      const found = await findPrompt(prompt.id);
      expect(found.template).toContain("{{topic}}");
      expect(found.template).toContain("{{style}}");
      expect(found.template).toContain("{{length}}");
    });
  });

  describe("Adapter integration", () => {
    it("supports multiple platforms per prompt", async () => {
      const prompt = await addPrompt({
        name: "Multi-platform",
        template: "Test",
        platforms: ["chatgpt", "claude", "perplexity", "gemini"]
      });

      expect(prompt.platforms).toHaveLength(4);
      expect(prompt.platforms).toContain("chatgpt");
      expect(prompt.platforms).toContain("claude");
      expect(prompt.platforms).toContain("perplexity");
      expect(prompt.platforms).toContain("gemini");
    });
  });

  describe("Error handling", () => {
    it("validates empty name", async () => {
      await expect(
        addPrompt({
          name: "",
          template: "Test",
          tags: [],
          platforms: []
        })
      ).rejects.toThrow();
    });

    it("validates empty template", async () => {
      await expect(
        addPrompt({
          name: "Test",
          template: "",
          tags: [],
          platforms: []
        })
      ).rejects.toThrow();
    });

    it("handles malformed library file gracefully", async () => {
      // This would require actual file manipulation
      // Just test that it returns empty when file doesn't exist
      const library = await loadPromptLibrary();
      expect(Array.isArray(library)).toBe(true);
    });
  });

  describe("Conversation thread capture", () => {
    it("throws error for unsupported platform", async () => {
      await expect(
        captureThread("unsupported-platform")
      ).rejects.toThrow(/Unsupported platform/);
    });

    it("returns correct thread capture result structure", async () => {
      // Mock Playwright and ensure captureThread returns structured result
      vi.doMock("playwright", () => ({
        chromium: {
          launch: vi.fn(async () => ({
            newContext: vi.fn(async () => ({
              newPage: vi.fn(async () => ({
                goto: vi.fn(async () => {}),
                waitForTimeout: vi.fn(async () => {}),
                evaluate: vi.fn(async () => [
                  { role: "user", content: "Hello" },
                  { role: "assistant", content: "Hi there!" }
                ]),
                close: vi.fn(async () => {})
              })),
              close: vi.fn(async () => {})
            })),
            close: vi.fn(async () => {})
          }))
        },
        firefox: {
          launch: vi.fn(async () => ({
            newContext: vi.fn(async () => ({
              newPage: vi.fn(async () => ({
                goto: vi.fn(async () => {}),
                waitForTimeout: vi.fn(async () => {}),
                evaluate: vi.fn(async () => [
                  { role: "user", content: "Hello" },
                  { role: "assistant", content: "Hi there!" }
                ]),
                close: vi.fn(async () => {})
              })),
              close: vi.fn(async () => {})
            })),
            close: vi.fn(async () => {})
          }))
        }
      }));

      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      await fs.mkdir(responsesDir, { recursive: true, mode: 0o700 });

      const result = await captureThread("chatgpt", { outputDir: responsesDir });

      expect(result).toHaveProperty("filename");
      expect(result.filename).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-chatgpt-thread\.md$/);
      expect(result).toHaveProperty("turns");
      expect(Array.isArray(result.turns)).toBe(true);
      expect(result.turns.length).toBe(2);
      expect(result.turns[0]).toHaveProperty("role");
      expect(result.turns[0]).toHaveProperty("content");
      expect(result.platform).toBe("chatgpt");

      const fileContents = await fs.readFile(result.filePath, "utf8");
      expect(fileContents).toContain("platform: chatgpt");
      expect(fileContents).toContain("captured_at:");
      expect(fileContents).toContain("turn_count: 2");
    });

    it("handles default thread selectors for known platforms", () => {
      const platforms = ["chatgpt", "claude", "gemini", "perplexity"];
      
      for (const platform of platforms) {
        const result = {
          filePath: `/path/to/${platform}-thread.md`,
          platform,
          turns: 1
        };
        
        expect(result.platform).toBe(platform);
        expect(result).toHaveProperty("filePath");
      }
    });

    it("writes thread files atomically to output directory", async () => {
      // Test that atomic write path exists and files are created safely
      const basePath = path.join(tempDir, ".vscode-rotator", "browser-responses");
      await fs.mkdir(basePath, { recursive: true, mode: 0o700 });
      
      // Verify output directory structure
      const stat = await fs.stat(basePath);
      expect(stat.isDirectory()).toBe(true);
    });
  });

  describe("CLI integration (capture & ingest)", () => {
    it("prints summary with turn and chunk counts", async () => {
      // Mock captureThread to return a predictable result
      const mockCapture = vi.spyOn(await import("../src/browser-bridge.js"), "captureThread");
      mockCapture.mockResolvedValueOnce({
        filename: "2026-05-20T12-00-00-chatgpt-thread.md",
        turns: [
          { role: "user", content: "Hello" },
          { role: "assistant", content: "Hi" }
        ],
        platform: "chatgpt",
        filePath: path.join(tempDir, ".vscode-rotator", "browser-responses", "2026-05-20T12-00-00-chatgpt-thread.md"),
        capturedAt: new Date().toISOString()
      });

      // Mock ingestThread to report chunks
      const ingestSpy = vi.spyOn((await import("../src/llm/document-ingester.js")).DocumentIngester.prototype, "ingestThread");
      ingestSpy.mockResolvedValueOnce({ path: "", chunks: 2 });

      const { captureAndIngest } = await import("../src/commands/browser.js");

      const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});

      const result = await captureAndIngest("chatgpt", path.join(tempDir, ".vscode-rotator", "browser-responses"));

      // Simulate CLI message printing as the command would
      console.log(`Captured ${result.turns.length} turns from ${result.platform}. Ingested ${result.chunksIngested} chunks.`);

      expect(logSpy).toHaveBeenCalled();
      const calledWith = logSpy.mock.calls.flat().join(" ");
      expect(calledWith).toContain("Captured 2 turns");
      expect(calledWith).toContain("Ingested 2 chunks");

      // Restore spies
      mockCapture.mockRestore();
      ingestSpy.mockRestore();
      logSpy.mockRestore();
    });

    it("executes browser capture --platform chatgpt --thread via CLI smoke test", async () => {
      vi.doMock("playwright", () => ({
        chromium: {
          launch: vi.fn(async () => ({
            newContext: vi.fn(async () => ({
              newPage: vi.fn(async () => ({
                goto: vi.fn(async () => {}),
                waitForTimeout: vi.fn(async () => {}),
                evaluate: vi.fn(async () => [
                  { role: "user", content: "Hello" },
                  { role: "assistant", content: "Hi there!" }
                ]),
                close: vi.fn(async () => {})
              })),
              close: vi.fn(async () => {})
            })),
            close: vi.fn(async () => {})
          }))
        },
        firefox: {
          launch: vi.fn(async () => ({
            newContext: vi.fn(async () => ({
              newPage: vi.fn(async () => ({
                goto: vi.fn(async () => {}),
                waitForTimeout: vi.fn(async () => {}),
                evaluate: vi.fn(async () => [
                  { role: "user", content: "Hello" },
                  { role: "assistant", content: "Hi there!" }
                ]),
                close: vi.fn(async () => {})
              })),
              close: vi.fn(async () => {})
            })),
            close: vi.fn(async () => {})
          }))
        }
      }));

      const { bindBrowserCommands } = await import("../src/commands/browser.js");
      const program = new Command();
      bindBrowserCommands(program);
      program.exitOverride();

      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      await fs.mkdir(responsesDir, { recursive: true, mode: 0o700 });

      const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      await program.parseAsync([
        "browser",
        "capture",
        "--platform",
        "chatgpt",
        "--thread",
        "--output-dir",
        responsesDir
      ], { from: "user" });

      expect(errorSpy).not.toHaveBeenCalled();
      expect(logSpy).toHaveBeenCalled();

      const files = await fs.readdir(responsesDir);
      expect(files.some((file) => file.endsWith("-chatgpt-thread.md"))).toBe(true);

      logSpy.mockRestore();
      errorSpy.mockRestore();
    });
  });

  describe("Thread ingestion", () => {
    it("ingests a thread file into per-turn chunks with metadata", async () => {
      await ensureBrowserDirs();
      const responsesDir = path.join(tempDir, ".vscode-rotator", "browser-responses");
      await fs.mkdir(responsesDir, { recursive: true, mode: 0o700 });

      const threadContent = `---\nplatform: chatgpt\ncaptured: 2026-05-20T12:00:00Z\ntype: thread\nturns: 2\n---\n\n## Turn 1 — user\n\nHello\n\n## Turn 2 — assistant\n\nHi there!\n`;
      const threadPath = path.join(responsesDir, "2026-05-20T12-00-00-chatgpt-thread.md");
      await fs.writeFile(threadPath, threadContent, "utf8");

      const ingester = new DocumentIngester({ baseDir: path.join(tempDir, ".vscode-rotator") });
      const result = await ingester.ingestThread(threadPath, { platform: "chatgpt" });

      expect(result.chunks).toBeGreaterThanOrEqual(2);

      const db = new ExperienceDb({ baseDir: path.join(tempDir, ".vscode-rotator") });
      await db.open();
      const docs = await db.getDocumentsByFile(threadPath);
      await db.close();

      expect(docs.length).toBeGreaterThanOrEqual(2);
      expect(docs[0].metadata).toBeDefined();
      expect(docs[0].metadata.turn).toBeDefined();
      expect(docs[0].metadata.role).toBeDefined();
      expect(docs[0].metadata.thread_file).toContain("thread.md");
    });
  });
});

