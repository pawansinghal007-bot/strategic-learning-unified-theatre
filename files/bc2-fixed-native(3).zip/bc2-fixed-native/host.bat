@echo off
python "C:\BrowserCapture\host.py" %* 2>>"%APPDATA%\BrowserCapture\host_stderr.log"
