// ── Content Script v2 ──
// Generic page capture + per-site AI chat capture via adapters

(function () {
  'use strict';

  const SESSION_ID = crypto.randomUUID
    ? crypto.randomUUID()
    : Date.now() + '-' + Math.random().toString(36).slice(2);
  const SITE = location.hostname;

  // ── Communicate with background ──
  function emit(type, payload = {}) {
    try {
      (typeof browser !== 'undefined' ? browser : chrome).runtime.sendMessage({
        type,
        sessionId: SESSION_ID,
        site:      SITE,
        url:       location.href,
        title:     document.title,
        ts:        new Date().toISOString(),
        payload
      });
    } catch (_) {}
  }

  // ── DOM path helper ──
  function cssPath(el) {
    if (!el) return '';
    const parts = [];
    while (el && el !== document.body) {
      let seg = el.tagName.toLowerCase();
      if (el.id) { seg += '#' + el.id; break; }
      else if (el.className) seg += '.' + String(el.className).trim().split(/\s+/)[0];
      parts.unshift(seg);
      el = el.parentElement;
    }
    return parts.slice(-4).join(' > ');
  }

  // ── Safe value (skip passwords) ──
  function getSafeValue(el) {
    if (el.type === 'password') return '[REDACTED]';
    return (el.value || el.innerText || '').trim().slice(0, 2000);
  }

  // ══════════════════════════════════════
  // 1. Generic page events
  // ══════════════════════════════════════

  emit('page_view');

  document.addEventListener('click', (e) => {
    const el = e.target.closest("button,a,[role='button']");
    if (!el) return;
    emit('click', {
      text:     (el.innerText || '').slice(0, 300),
      selector: cssPath(el)
    });
  }, true);

  // Debounced input capture
  const inputTimers = new WeakMap();
  document.addEventListener('input', (e) => {
    const el = e.target;
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el.isContentEditable)) return;
    clearTimeout(inputTimers.get(el));
    inputTimers.set(el, setTimeout(() => {
      emit('input_change', {
        selector:  cssPath(el),
        value:     getSafeValue(el),
        fieldName: el.name || el.getAttribute('aria-label') || el.tagName
      });
    }, 1500));
  }, true);

  // Selection capture
  document.addEventListener('mouseup', () => {
    const sel = window.getSelection()?.toString().trim();
    if (sel && sel.length > 15) {
      emit('text_selected', { value: sel.slice(0, 1000) });
    }
  });

  // ══════════════════════════════════════
  // 2. AI chat capture
  // ══════════════════════════════════════

  // Adapter definitions (inline so no import needed in content script context)
  const ADAPTERS = {
    'chat.openai.com': {
      name: 'openai',
      promptInput:     '#prompt-textarea',
      msgContainer:    '.flex.flex-col.items-center',
      userMsgSel:      '[data-message-author-role="user"]',
      assistantMsgSel: '[data-message-author-role="assistant"]',
      sendBtn:         'button[data-testid="send-button"]',
      extractModel()   { return document.querySelector('[data-testid="model-switcher-button"]')?.innerText?.trim() || null; },
      extractConvId()  { const m = location.pathname.match(/\/c\/([a-zA-Z0-9-]+)/); return m?.[1] || null; },
    },
    'claude.ai': {
      name: 'claude',
      promptInput:     'div[contenteditable="true"]',
      msgContainer:    '.flex-1.overflow-y-auto',
      userMsgSel:      '[data-testid="user-message"]',
      assistantMsgSel: '[data-testid="ai-response"]',
      sendBtn:         'button[aria-label="Send Message"]',
      extractModel()   { return 'claude'; },
      extractConvId()  { const m = location.pathname.match(/\/chat\/([a-zA-Z0-9-]+)/); return m?.[1] || null; },
    },
    'gemini.google.com': {
      name: 'gemini',
      promptInput:     'rich-textarea div[contenteditable="true"]',
      msgContainer:    'conversation-container',
      userMsgSel:      '.user-query-text',
      assistantMsgSel: '.model-response-text',
      sendBtn:         'button.send-button',
      extractModel()   { return document.querySelector('.model-name-text')?.innerText?.trim() || 'gemini'; },
      extractConvId()  { const m = location.pathname.match(/\/app\/([a-zA-Z0-9]+)/); return m?.[1] || null; },
    },
    'www.perplexity.ai': {
      name: 'perplexity',
      promptInput:     'textarea[placeholder]',
      msgContainer:    'main .mx-auto',
      userMsgSel:      '.font-medium.break-words',
      assistantMsgSel: '.prose',
      sendBtn:         'button[aria-label="Submit"]',
      extractModel()   { return 'perplexity'; },
      extractConvId()  { const m = location.pathname.match(/\/search\/([a-zA-Z0-9-]+)/); return m?.[1] || null; },
    }
  };

  const adapter = ADAPTERS[SITE];
  if (!adapter) return; // Non-AI site — generic capture is sufficient

  let chatInitTimer = null;

  function initChatCapture() {
    // Wait for container to appear in DOM
    const container = document.querySelector(adapter.msgContainer);
    if (!container) {
      clearTimeout(chatInitTimer);
      chatInitTimer = setTimeout(initChatCapture, 1500);
      return;
    }

    // Capture send button clicks (user prompt)
    document.addEventListener('click', (e) => {
      const btn = e.target.closest(adapter.sendBtn);
      if (!btn) return;
      const inputEl = document.querySelector(adapter.promptInput);
      const text = getSafeValue(inputEl || document.createElement('div'));
      if (!text) return;
      emit('prompt_submit', {
        role:           'user',
        text,
        model:          adapter.extractModel(),
        conversationId: adapter.extractConvId(),
        final:          true
      });
    }, true);

    // Observe assistant replies via MutationObserver
    const seen = new Map(); // messageId/element -> last text

    const observer = new MutationObserver(() => {
      if (!adapter.assistantMsgSel) return;
      document.querySelectorAll(adapter.assistantMsgSel).forEach(el => {
        const text = el.innerText.trim();
        if (!text || text.length < 5) return;

        const key = el;
        const prev = seen.get(key);
        if (prev === text) return; // no change
        seen.set(key, text);

        // Heuristic: if the element still has a streaming indicator, it's not final
        const isStreaming =
          !!el.querySelector('.result-streaming, .cursor-blink, [data-is-streaming]') ||
          el.classList.contains('streaming');

        emit(isStreaming ? 'assistant_chunk' : 'assistant_message_final', {
          role:           'assistant',
          text:           text.slice(0, 8000),
          model:          adapter.extractModel(),
          conversationId: adapter.extractConvId(),
          messageId:      el.getAttribute('data-message-id') || null,
          final:          !isStreaming
        });
      });
    });

    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  // Start after DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initChatCapture);
  } else {
    initChatCapture();
  }

})();
