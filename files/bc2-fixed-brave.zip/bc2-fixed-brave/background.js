// ── Background / Service Worker ──
// Bridges content scripts to native host; handles popup auth messages

const NATIVE_HOST = 'com.garuda.browser_capture';

let port = null;
const msgQueue = [];

function connectHost() {
  try {
    port = chrome.runtime.connectNative(NATIVE_HOST);
    port.onMessage.addListener(handleHostResponse);
    port.onDisconnect.addListener(() => {
      const err = chrome.runtime.lastError?.message;
      console.warn('[BC] Host disconnected:', err);
      port = null;
      setTimeout(connectHost, 3000);
    });
    // Flush queued messages
    while (msgQueue.length) sendToHost(msgQueue.shift());
    console.log('[BC] Native host connected');
  } catch (e) {
    console.error('[BC] Connect failed:', e);
    setTimeout(connectHost, 3000);
  }
}

function sendToHost(msg) {
  if (!port) {
    if (msgQueue.length < 200) msgQueue.push(msg);
    return;
  }
  try {
    port.postMessage(msg);
  } catch (e) {
    console.error('[BC] postMessage failed:', e);
    port = null;
    msgQueue.push(msg);
    connectHost();
  }
}

// Pending popup callbacks: requestId -> { resolve }
const pendingCallbacks = new Map();

function handleHostResponse(response) {
  // Route auth responses back to popup via stored callback
  const id = response._requestId;
  if (id && pendingCallbacks.has(id)) {
    pendingCallbacks.get(id)(response);
    pendingCallbacks.delete(id);
  }
}

function detectBrowser() {
  if (navigator.brave?.isBrave) return 'brave';
  if (typeof InstallTrigger !== 'undefined') return 'firefox';
  return 'chrome';
}

// ── Listen from content scripts ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const event = {
    ...msg,
    browser: detectBrowser(),
    tabId:   sender.tab?.id ?? null
  };

  // Auth requests from popup need a response
  if (msg.type === 'create_user' || msg.type === 'login') {
    const requestId = Date.now() + '-' + Math.random().toString(36).slice(2);
    event._requestId = requestId;
    pendingCallbacks.set(requestId, (res) => sendResponse(res));
    sendToHost(event);
    return true; // keep channel open for async sendResponse
  }

  // Ping: check if native host is alive
  if (msg.type === 'ping') {
    if (port) {
      const requestId = Date.now() + '-' + Math.random().toString(36).slice(2);
      event._requestId = requestId;
      pendingCallbacks.set(requestId, (res) => sendResponse(res));
      sendToHost(event);
    } else {
      sendResponse({ status: 'error', error: 'Host not connected' });
    }
    return true;
  }

  sendToHost(event);
  return false;
});

connectHost();
